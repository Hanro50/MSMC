import { gmllUser, mclcUser, mcProfile } from "../assets.js";
import xbox from "./xbox.js";
import { auth } from "./auth.js";
export interface mcJWTDecoded {
    xuid: string;
    agg: string;
    sub: string;
    nbf: number;
    auth: string;
    roles: [];
    iss: string;
    exp: number;
    iat: number;
    platform: string;
    yuid: string;
}
export declare type entitlements = "game_minecraft" | "game_minecraft_bedrock" | "game_dungeons" | "product_minecraft" | "product_minecraft_bedrock" | "product_dungeons";
export interface mcToken {
    refresh?: string;
    mcToken: string;
    profile: mcProfile;
    xuid: string;
    exp: number;
}
/**Validates MC tokens to check if they're valid. */
export declare function validate(token: mcToken | minecraft | mclcUser): boolean;
/**
 * Gets a minecraft token from a saved mcToken.
 * @param auth A new instance of the auth object
 * @param token The mcToken
 * @param refresh Set to true if we should try refreshing the token
 * @returns A newly serialized minecraft Token.
 *
 * @warning The xbox object may not be restored using this method!
 */
export declare function fromToken(auth: auth, token: mcToken): null | minecraft;
export declare function fromToken(auth: auth, token: mcToken, refresh?: boolean): Promise<minecraft>;
/**
 * Gets a minecraft token from a saved mcToken.
 * @param auth A new instance of the auth object
 * @param token The mcToken
 * @returns A newly serialized minecraft Token.
 *
 * @warning The xbox object may not be restored using this method!
 */
export declare function fromMclcToken(auth: auth, token: mclcUser, refresh?: boolean): null | minecraft | Promise<minecraft>;
export default class minecraft {
    readonly mcToken: string;
    readonly profile: mcProfile | undefined;
    readonly parent: xbox | auth;
    readonly xuid: string;
    readonly exp: number;
    refreshTkn: string;
    getToken(full: boolean): mcToken;
    constructor(mcToken: string, profile: mcProfile, parent: xbox);
    constructor(mcToken: string, profile: mcProfile, parent: auth, refreshTkn: string, exp: number);
    entitlements(): Promise<entitlements[]>;
    isDemo(): boolean;
    /**
     * A MCLC user object for launching minecraft
     * @param refreshable Should we embed some metadata for refreshable tokens?
     * @returns returns an MCLC user token
     *
     */
    mclc(refreshable?: boolean): mclcUser;
    gmll(): gmllUser;
    refresh(force?: boolean): Promise<this>;
    validate(): boolean;
    _parseLoginToken(): mcJWTDecoded;
}
