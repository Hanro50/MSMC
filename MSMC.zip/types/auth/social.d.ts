export declare class xplayer {
    auth: social;
    score: number;
    xuid: string;
    gamerTag: string;
    name: string;
    profilePictureURL: string;
    constructor(user: {
        id: string;
        settings: any[];
    }, auth: social);
    getFriends(): Promise<xplayer[]>;
}
export default class social {
    auth: string;
    constructor(auth: string);
    getProfile(xuid?: string): Promise<xplayer>;
    getFriends(xuid?: string): Promise<xplayer[]>;
    xGet(endpoint: string, xuid?: string): Promise<any>;
}
