import { lexcodes } from "../assets.js";
import { auth, msAuthToken } from "./auth.js";
import social from "./social.js";
import minecraft from "./minecraft.js";
export interface mcAuthToken {
    username: string;
    roles: [];
    access_token: string;
    token_type: string;
    expires_in: number;
}
export interface xblAuthToken {
    IssueInstant?: string;
    NotAfter?: string;
    Token: string;
    DisplayClaims?: {
        xui: [{
            uhs: string;
        }];
    };
}
export default class xbox {
    readonly parent: auth;
    readonly msToken: msAuthToken;
    readonly xblToken: xblAuthToken;
    readonly exp: number;
    constructor(parent: auth, MStoken: msAuthToken, xblToken: xblAuthToken);
    load(code: lexcodes): void;
    xAuth(RelyingParty?: string): Promise<string>;
    refresh(force?: boolean): Promise<this>;
    getSocial(): Promise<social>;
    getMinecraft(): Promise<minecraft>;
    validate(): boolean;
    /**
     * Feed this into the refresh funtion in the auth object that generated it.
     * @returns The refresh token
     */
    save(): string;
}
