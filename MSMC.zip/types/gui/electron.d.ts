import { auth } from "../auth/auth.js";
declare const _default: (auth: auth, Windowproperties?: import("../assets.js").windowProperties) => Promise<unknown>;
export default _default;
